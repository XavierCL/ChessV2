#include "../../Headers/Boards/Board.h"

const std::hash<bool> Board::IS_WHITE_HASH;

const unsigned char Board::NUMBER_COLUMN = 8;
const unsigned char Board::NUMBER_ROW = 8;