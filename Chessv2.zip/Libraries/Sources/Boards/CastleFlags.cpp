#include "../../Headers/Boards/CastleFlags.h"

const std::hash<bool> CastleFlags::ALLOWED_CASTLE_HASH;