#include "../../../Headers/Moves/Effectors/CastleMove.h"

const Option<unsigned long long> CastleMove::NO_CAPTURE_POSITION;