#include "../../../Headers/Moves/Effectors/PromotionMove.h"

const Option<unsigned long long> PromotionMove::NO_CAPTURE_DESTINATION;