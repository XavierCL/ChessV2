#include "../../../Headers/Moves/Effectors/SimpleMove.h"

const Option<unsigned long long> SimpleMove::NO_CAPTURE_DESTINATION;